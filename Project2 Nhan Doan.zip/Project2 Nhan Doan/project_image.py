from PIL import Image

def increase_brightness_background(image,level):
    result = image.copy()
    width, height = image.size
    for x in range(width):
        for y in range(height):
            r, g, b = image.getpixel((x, y))
            result.putpixel((x, y), (int(r*level), int(g*level), int(b*level)))
    return result

#edit the brightness of the background by giving the input
# and the level of brightness you want to increase
image = Image.open("background.jpg")
level = 0.5
image = increase_brightness_background(image,level)
image.save("background2.jpg")
#image.show()



def change_sweater_colour(image): 
    result = image.copy()
    width, height = image.size
    for x in range(width):
        for y in range(height):
            r, g, b = image.getpixel((x, y))
            result.putpixel((x, y), (255-r,255-g, 255-b))

    return result

#compute the colour change of sweater 
image = Image.open("sweater.jpg")
image = change_sweater_colour(image)
image.save("sweater2.jpg")
#image.show()



# this function would be used to revert the image
# so that the two images will opose each other at the end 
def revert_image(image, image_path):
    image = Image.open(image)
    result = image.transpose(Image.FLIP_LEFT_RIGHT)
    # Save new reverted image
    result.save(image_path)
    #result.show()



def cut_paste_image(og_image_path, inserted_image_path, position_cut, position_insert, new_size, new_image):
    # open the orginal image 
    image1 = Image.open(og_image_path)
    # cut the image
    region = image1.crop(position_cut)
    # resize the cutted image
    region_resize = region.resize(new_size)
    # open the image so that we can paste the cutted image on it
    image2 = Image.open(inserted_image_path)
    # insert the cutted image into the image and resize it
    image2.paste(region_resize, position_insert)
    # save new image
    image2.save(new_image)

#Replace face and insert a new face
face = "face.jpg"
body = "body.jpg"
# position_cut (left, top, right, bottom)
position_face = (300, 20, 500, 300)
# new size of face
face_size = (150, 150)
# inserted region (left, top)
inserted_face = (280, 30)
# new path
save_image_1 = "image_1.jpg"
# calling function
cut_paste_image(face, body, position_face, inserted_face, face_size, save_image_1)

#Replace a jacket and insert a new sweater and insert it to image_1
sweater = "sweater2.jpg"
position_sweater = (100,300,1200,1750)
size_sweater = (300,400)
position_inserted_sweater = (180,170)
save_image_2 = "image_2.jpg"
cut_paste_image(sweater, save_image_1, position_sweater, position_inserted_sweater, size_sweater, save_image_2)


#add the adjusted image to the new background_2 
whole_body = save_image_2
background = "background2.jpg"
position_person = (160,10,540,1000)
size_person = (1000,2000)
postion_inserted_person = (1000,1000)
save_image_3 = "image_3.jpg"
cut_paste_image(whole_body, background, position_person, postion_inserted_person, size_person, save_image_3)


#Using rever function to revert the editted image
image = save_image_2
image_revert= "revert.jpg"
#test function
revert_image(image, image_revert)

#add the reverted image to the new background_2
reverted_person = image_revert
background_3 = save_image_3
position_reverted_person = (100,10,700,1000)
size_reverted = (1000,2000)
inserted_reverted = (2100,1000)
save_image_4 = "image_4.jpg"
cut_paste_image(reverted_person, background_3, position_reverted_person, inserted_reverted, size_reverted, save_image_4)
image = Image.open(save_image_4)
image.show()